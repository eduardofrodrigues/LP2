﻿namespace PTriangulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtBLado1 = new System.Windows.Forms.TextBox();
            this.txtBLado2 = new System.Windows.Forms.TextBox();
            this.txtBLado3 = new System.Windows.Forms.TextBox();
            this.lblLado1 = new System.Windows.Forms.Label();
            this.lblLado2 = new System.Windows.Forms.Label();
            this.lblLado3 = new System.Windows.Forms.Label();
            this.btnVerificar = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblDescricao = new System.Windows.Forms.Label();
            this.lblTipo = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtBLado1
            // 
            this.txtBLado1.Location = new System.Drawing.Point(349, 84);
            this.txtBLado1.Name = "txtBLado1";
            this.txtBLado1.Size = new System.Drawing.Size(221, 26);
            this.txtBLado1.TabIndex = 0;
            this.txtBLado1.Validated += new System.EventHandler(this.txtBLado1_Validated);
            // 
            // txtBLado2
            // 
            this.txtBLado2.Location = new System.Drawing.Point(349, 169);
            this.txtBLado2.Name = "txtBLado2";
            this.txtBLado2.Size = new System.Drawing.Size(221, 26);
            this.txtBLado2.TabIndex = 1;
            this.txtBLado2.Validated += new System.EventHandler(this.txtBLado2_Validated);
            // 
            // txtBLado3
            // 
            this.txtBLado3.Location = new System.Drawing.Point(349, 253);
            this.txtBLado3.Name = "txtBLado3";
            this.txtBLado3.Size = new System.Drawing.Size(221, 26);
            this.txtBLado3.TabIndex = 2;
            this.txtBLado3.Validated += new System.EventHandler(this.txtBLado3_Validated);
            // 
            // lblLado1
            // 
            this.lblLado1.AutoSize = true;
            this.lblLado1.Location = new System.Drawing.Point(90, 87);
            this.lblLado1.Name = "lblLado1";
            this.lblLado1.Size = new System.Drawing.Size(180, 20);
            this.lblLado1.TabIndex = 3;
            this.lblLado1.Text = "Tamanho Lado 1 em cm";
            // 
            // lblLado2
            // 
            this.lblLado2.AutoSize = true;
            this.lblLado2.Location = new System.Drawing.Point(90, 172);
            this.lblLado2.Name = "lblLado2";
            this.lblLado2.Size = new System.Drawing.Size(180, 20);
            this.lblLado2.TabIndex = 4;
            this.lblLado2.Text = "Tamanho Lado 2 em cm";
            // 
            // lblLado3
            // 
            this.lblLado3.AutoSize = true;
            this.lblLado3.Location = new System.Drawing.Point(90, 256);
            this.lblLado3.Name = "lblLado3";
            this.lblLado3.Size = new System.Drawing.Size(180, 20);
            this.lblLado3.TabIndex = 5;
            this.lblLado3.Text = "Tamanho Lado 3 em cm";
            // 
            // btnVerificar
            // 
            this.btnVerificar.Location = new System.Drawing.Point(94, 338);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(176, 62);
            this.btnVerificar.TabIndex = 6;
            this.btnVerificar.Text = "VERIFICAR";
            this.btnVerificar.UseVisualStyleBackColor = true;
            this.btnVerificar.Click += new System.EventHandler(this.btnVerificar_Click);
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(229, 9);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(337, 25);
            this.lblTitle.TabIndex = 7;
            this.lblTitle.Text = "VERIFICADOR DE TRIÂNGULOS";
            // 
            // lblDescricao
            // 
            this.lblDescricao.AutoSize = true;
            this.lblDescricao.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescricao.Location = new System.Drawing.Point(345, 371);
            this.lblDescricao.Name = "lblDescricao";
            this.lblDescricao.Size = new System.Drawing.Size(225, 20);
            this.lblDescricao.TabIndex = 8;
            this.lblDescricao.Text = "PREENCHA OS VALORES";
            // 
            // lblTipo
            // 
            this.lblTipo.AutoSize = true;
            this.lblTipo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTipo.Location = new System.Drawing.Point(345, 338);
            this.lblTipo.Name = "lblTipo";
            this.lblTipo.Size = new System.Drawing.Size(192, 20);
            this.lblTipo.TabIndex = 9;
            this.lblTipo.Text = "TIPO DE TRIÂNGULO:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(676, 450);
            this.Controls.Add(this.lblTipo);
            this.Controls.Add(this.lblDescricao);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.btnVerificar);
            this.Controls.Add(this.lblLado3);
            this.Controls.Add(this.lblLado2);
            this.Controls.Add(this.lblLado1);
            this.Controls.Add(this.txtBLado3);
            this.Controls.Add(this.txtBLado2);
            this.Controls.Add(this.txtBLado1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtBLado1;
        private System.Windows.Forms.TextBox txtBLado2;
        private System.Windows.Forms.TextBox txtBLado3;
        private System.Windows.Forms.Label lblLado1;
        private System.Windows.Forms.Label lblLado2;
        private System.Windows.Forms.Label lblLado3;
        private System.Windows.Forms.Button btnVerificar;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblDescricao;
        private System.Windows.Forms.Label lblTipo;
    }
}

