﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtBLado1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtBLado1.Text, out _))
            {
                MessageBox.Show("Valor do lado 1 inválido");
            }
        }

        private void txtBLado2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtBLado2.Text, out _))
            {
                MessageBox.Show("Valor do lado 2 inválido");
            }
        }

        private void txtBLado3_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtBLado3.Text, out _))
            {
                MessageBox.Show("Valor do lado 3 inválido");
            }
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double vlrLado1 = 0, vlrLado2 = 0, vlrLado3 = 0;
            if (!double.TryParse(txtBLado1.Text, out vlrLado1) ||
                !double.TryParse(txtBLado2.Text, out vlrLado2) ||
                !double.TryParse(txtBLado3.Text, out vlrLado3))
            {
                MessageBox.Show("Um dos valores estão inválidos");
            }

            // os lados informados formam um triângulo?
            if ((vlrLado1 < (vlrLado2 + vlrLado3)) && (vlrLado2 < (vlrLado1 + vlrLado3))
                && (vlrLado3 < (vlrLado1 + vlrLado2)))
            {
                // é um triângulo equilátero (todos os lados iguais)?
                if ((vlrLado1 == vlrLado2) && (vlrLado2 == vlrLado3))
                {
                    lblDescricao.Text = "O triângulo é equilátero";
                }
                else
                {
                    // é isósceles (dois lados iguais e um diferente)?
                    if ((vlrLado1 == vlrLado2) || (vlrLado1 == vlrLado3) || (vlrLado3 == vlrLado2))
                    {
                        lblDescricao.Text = "O triângulo é isósceles";
                    }
                    else
                    {
                        // é escaleno
                        lblDescricao.Text = "O triângulo é escaleno";
                    }
                }
            }
            else
            {
                lblDescricao.Text = "Não forma um triâgulo";
            }
        }
    }
}
