﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBRaio_Validated(object sender, EventArgs e)
        {
            double vlrRaio;

            if (!double.TryParse(textBRaio.Text,out vlrRaio))
            {
                MessageBox.Show("Raio Inválido");
            }
        }

        private void textBAltura_Validated(object sender, EventArgs e)
        {
            double vlrAltura;
            if (!double.TryParse(textBAltura.Text, out vlrAltura))
            {
                MessageBox.Show("Altura Inválida");
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double vlrRaio, vlrAltura;
            if ((!double.TryParse(textBAltura.Text, out vlrAltura)) ||
                (!double.TryParse(textBRaio.Text, out vlrRaio)))
            {
                MessageBox.Show("Valores Inválidos");
            } else
            {
                double vlrVolume;
                vlrVolume = Math.PI * Math.Pow(vlrRaio, 2) * vlrAltura;
                textBVolume.Text = vlrVolume.ToString("N2");
            }
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
