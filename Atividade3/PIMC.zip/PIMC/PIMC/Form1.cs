﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtBPeso_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(txtBPeso.Text, out _))
            {
                MessageBox.Show("Valor do peso incorreto");
            }
        }

        private void txtBAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtBAltura.Text, out _))
            {
                MessageBox.Show("Valor da altura incorreto");
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double vlrPeso = 0, vlrAltura = 0, IMC = 0;

            if((!double.TryParse(txtBAltura.Text, out vlrAltura)) || (!double.TryParse(txtBPeso.Text, out vlrPeso)))
            {
                MessageBox.Show("Valores incorretos");
            }

            IMC = vlrPeso / Math.Pow(vlrAltura, 2);


            if (IMC < 18.5)
            {
                lblClassificacao.Text = $"{IMC.ToString("N2")} - MAGREZA";
            }
            else if ((IMC >= 18.5) && (IMC <= 24.9))
            {
                lblClassificacao.Text = $"{IMC.ToString("N2")} - NORMAL";
            }
            else if ((IMC >= 25) && (IMC <= 29.9))
            {
                lblClassificacao.Text = $"{IMC.ToString("N2")} - SOBREPESO";
            }
            else if ((IMC >= 30) && (IMC <= 39.9))
            {
                lblClassificacao.Text = $"{IMC.ToString("N2")} - OBESIDADE";
            }
            else
            {
                lblClassificacao.Text = $"{IMC.ToString("N2")} - OBESIDADE GRAVE";
            }

        }
    }
}
