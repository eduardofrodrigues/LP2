﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void textBNumero1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(textBNumero1.Text, out _))
            {
                MessageBox.Show("Número 1 inválido");
            }
        }
        private void textBNumero2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(textBNumero2.Text, out _))
            {
                MessageBox.Show("Número 2 inválido");
            }
        }

        private void btnMais_Click(object sender, EventArgs e)
        {
            double vlrNumero1 = 0, vlrNumero2 = 0, resultado = 0;
            if ((!double.TryParse(textBNumero1.Text, out vlrNumero1)) || (!double.TryParse(textBNumero2.Text, out vlrNumero2)))
            {
                MessageBox.Show("Valores inválidos");
            }

            resultado = vlrNumero1 + vlrNumero2;

            textBResultado.Text = resultado.ToString();
        }

        private void btnMenos_Click(object sender, EventArgs e)
        {
            double vlrNumero1 = 0, vlrNumero2 = 0, resultado = 0;
            if ((!double.TryParse(textBNumero1.Text, out vlrNumero1)) || (!double.TryParse(textBNumero2.Text, out vlrNumero2)))
            {
                MessageBox.Show("Valores inválidos");
            }

            resultado = vlrNumero1 - vlrNumero2;

            textBResultado.Text = resultado.ToString();
        }

        private void btnVezes_Click(object sender, EventArgs e)
        {
            double vlrNumero1 = 0, vlrNumero2 = 0, resultado = 0;
            if ((!double.TryParse(textBNumero1.Text, out vlrNumero1)) || (!double.TryParse(textBNumero2.Text, out vlrNumero2)))
            {
                MessageBox.Show("Valores inválidos");
            }

            resultado = vlrNumero1 * vlrNumero2;

            textBResultado.Text = resultado.ToString();
        }

        private void btnDividir_Click(object sender, EventArgs e)
        {
            double vlrNumero1 = 0, vlrNumero2 = 0, resultado = 0;
            if ((!double.TryParse(textBNumero1.Text, out vlrNumero1)) || (!double.TryParse(textBNumero2.Text, out vlrNumero2)))
            {
                MessageBox.Show("Valores inválidos");
            }

            resultado = vlrNumero1 / vlrNumero2;

            textBResultado.Text = resultado.ToString();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            textBNumero1.Text = string.Empty;
            textBNumero2.Text = string.Empty;
            textBResultado.Text = string.Empty;
        }
    }
}
