﻿namespace PCalc
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBNumero1 = new System.Windows.Forms.TextBox();
            this.textBNumero2 = new System.Windows.Forms.TextBox();
            this.textBResultado = new System.Windows.Forms.TextBox();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnVezes = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.btnDividir = new System.Windows.Forms.Button();
            this.btnMenos = new System.Windows.Forms.Button();
            this.btnMais = new System.Windows.Forms.Button();
            this.lblNumero1 = new System.Windows.Forms.Label();
            this.lblResultado = new System.Windows.Forms.Label();
            this.lblNumero2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBNumero1
            // 
            this.textBNumero1.Location = new System.Drawing.Point(159, 55);
            this.textBNumero1.Multiline = true;
            this.textBNumero1.Name = "textBNumero1";
            this.textBNumero1.Size = new System.Drawing.Size(216, 36);
            this.textBNumero1.TabIndex = 0;
            this.textBNumero1.Validated += new System.EventHandler(this.textBNumero1_Validated);
            // 
            // textBNumero2
            // 
            this.textBNumero2.Location = new System.Drawing.Point(159, 162);
            this.textBNumero2.Multiline = true;
            this.textBNumero2.Name = "textBNumero2";
            this.textBNumero2.Size = new System.Drawing.Size(216, 36);
            this.textBNumero2.TabIndex = 1;
            this.textBNumero2.Validated += new System.EventHandler(this.textBNumero2_Validated);
            // 
            // textBResultado
            // 
            this.textBResultado.Enabled = false;
            this.textBResultado.Location = new System.Drawing.Point(159, 272);
            this.textBResultado.Multiline = true;
            this.textBResultado.Name = "textBResultado";
            this.textBResultado.Size = new System.Drawing.Size(216, 36);
            this.textBResultado.TabIndex = 2;
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(446, 55);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(283, 68);
            this.btnLimpar.TabIndex = 3;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnVezes
            // 
            this.btnVezes.Location = new System.Drawing.Point(404, 365);
            this.btnVezes.Name = "btnVezes";
            this.btnVezes.Size = new System.Drawing.Size(166, 68);
            this.btnVezes.TabIndex = 4;
            this.btnVezes.Text = "*";
            this.btnVezes.UseVisualStyleBackColor = true;
            this.btnVezes.Click += new System.EventHandler(this.btnVezes_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(446, 199);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(283, 68);
            this.btnSair.TabIndex = 5;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // btnDividir
            // 
            this.btnDividir.Location = new System.Drawing.Point(600, 365);
            this.btnDividir.Name = "btnDividir";
            this.btnDividir.Size = new System.Drawing.Size(166, 68);
            this.btnDividir.TabIndex = 6;
            this.btnDividir.Text = "/";
            this.btnDividir.UseVisualStyleBackColor = true;
            this.btnDividir.Click += new System.EventHandler(this.btnDividir_Click);
            // 
            // btnMenos
            // 
            this.btnMenos.Location = new System.Drawing.Point(209, 365);
            this.btnMenos.Name = "btnMenos";
            this.btnMenos.Size = new System.Drawing.Size(166, 68);
            this.btnMenos.TabIndex = 7;
            this.btnMenos.Text = "-";
            this.btnMenos.UseVisualStyleBackColor = true;
            this.btnMenos.Click += new System.EventHandler(this.btnMenos_Click);
            // 
            // btnMais
            // 
            this.btnMais.Location = new System.Drawing.Point(12, 365);
            this.btnMais.Name = "btnMais";
            this.btnMais.Size = new System.Drawing.Size(166, 68);
            this.btnMais.TabIndex = 8;
            this.btnMais.Text = "+";
            this.btnMais.UseVisualStyleBackColor = true;
            this.btnMais.Click += new System.EventHandler(this.btnMais_Click);
            // 
            // lblNumero1
            // 
            this.lblNumero1.AutoSize = true;
            this.lblNumero1.Location = new System.Drawing.Point(36, 58);
            this.lblNumero1.Name = "lblNumero1";
            this.lblNumero1.Size = new System.Drawing.Size(78, 20);
            this.lblNumero1.TabIndex = 9;
            this.lblNumero1.Text = "Número 1";
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Location = new System.Drawing.Point(36, 275);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(82, 20);
            this.lblResultado.TabIndex = 10;
            this.lblResultado.Text = "Resultado";
            // 
            // lblNumero2
            // 
            this.lblNumero2.AutoSize = true;
            this.lblNumero2.Location = new System.Drawing.Point(36, 165);
            this.lblNumero2.Name = "lblNumero2";
            this.lblNumero2.Size = new System.Drawing.Size(78, 20);
            this.lblNumero2.TabIndex = 11;
            this.lblNumero2.Text = "Número 2";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(779, 450);
            this.Controls.Add(this.lblNumero2);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.lblNumero1);
            this.Controls.Add(this.btnMais);
            this.Controls.Add(this.btnMenos);
            this.Controls.Add(this.btnDividir);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnVezes);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.textBResultado);
            this.Controls.Add(this.textBNumero2);
            this.Controls.Add(this.textBNumero1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBNumero1;
        private System.Windows.Forms.TextBox textBNumero2;
        private System.Windows.Forms.TextBox textBResultado;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnVezes;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Button btnDividir;
        private System.Windows.Forms.Button btnMenos;
        private System.Windows.Forms.Button btnMais;
        private System.Windows.Forms.Label lblNumero1;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.Label lblNumero2;
    }
}

